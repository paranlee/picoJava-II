#!/usr/dist/exe/perl -w

$classname = "stress_isq";
$NUM_LEVELS = 72;
$NUM_LVARS = 72;
# $NUM_ITER = 10;
$fname = "long_function_name";
$JVM = 0;

print "class $classname {\nstatic int level;\n";

# declare proto
for ($i = 0 ; $i < $NUM_LVARS ; $i++) {
    $nargs = $i;
    printf ("static int ${fname}%d (", $nargs);

    for ($j = 0 ; $j < $nargs ; $j++) {
        printf ("int a%d", $j);
        ($j != ($nargs-1)) ? printf (", ") : 0 ;
	}

# declare locals
	print ")\n{\nint ";

    $nlocals = $NUM_LVARS - $i;

    for ($j = 0 ; $j < $nlocals ; $j++) {
        printf ("i%d", $j);
        ($j != $nlocals-1) ? printf (", ") : 0;
	}

	printf (";\nlevel++;\nif (level > $NUM_LEVELS) { return ($NUM_LVARS*($NUM_LVARS-1)/2);}\n");
#    printf ("System.out.println (\"in function with nargs = %d\");\n", $nargs);

# go in reverse order of lvars - some (little) hope of resonating with sc_bottom
# init locals
 	for ($j = $nlocals-1 ; $j >= 0 ; $j--)
	{ printf ("i%d = 0; ", $j, $j);}
	printf ("\n");
# init args
	for ($j = $nargs-1 ; $j >= 0 ; $j--)
	{ printf ("a%d = 0; ", $j, $j);}
	printf ("\n");

# decr locals
 	for ($j = $nlocals-1 ; $j >= 0 ; $j--)
	{ printf ("i%d -= 1; ", $j);}
	printf ("\n");
# decr args
	for ($j = $nargs-1 ; $j >= 0 ; $j--)
	{ printf ("a%d -= 1; ", $j);}
	printf ("\n");

# incr locals
 	for ($j = $nlocals-1 ; $j >= 0 ; $j--)
	{ printf ("i%d += %d; ", $j, $nargs+$j+1);}
	printf ("\n");
# incr args
	for ($j = $nargs-1 ; $j >= 0 ; $j--)
	{ printf ("a%d += %d; ", $j, $j+1);}
	printf ("\n");

# sum args
    printf ("int sum = 0");
	for ($j = 0 ; $j < $nargs ; $j++)
	{ 
	    printf (" + a%d", $j);
	}
	  
# sum locals
	for ($j = 0 ; $j < $nlocals ; $j++)
	{ 
	    printf (" + i%d", $j);
	}

	printf (";\n");
# check sum, call next fn, throw random exception if result is not as expected
	printf ("if (sum != $NUM_LVARS*($NUM_LVARS-1)/2) { throw new ArrayStoreException();}\n");

# arbitrary no. 59 - any relateively prime no. would do 
    $new_fn_nargs = ($nargs + 59) % ($NUM_LVARS);
	printf ("if (${fname}%d (", $new_fn_nargs);
	for ($k = 0 ; $k < $new_fn_nargs; $k++)
	{
	     printf ("0");
		 if ($k != $new_fn_nargs-1) {
		     printf (", ");
		 }
	}

	printf (") != $NUM_LVARS*($NUM_LVARS-1)/2) { throw new ArrayStoreException();}\n");
	printf ("return sum;\n}\n");
}

if ($JVM)
{    printf ("public static void main (String[] a)\n");} else
{    printf ("public static int main ()\n");}

printf ("{ \nif (${fname}0() != ($NUM_LVARS * ($NUM_LVARS-1)/2)) { throw new ArrayStoreException();}\n");

if ($JVM)
{    printf ("System.out.println (\"Test passed\"\n");} else
{    printf ("return 0;\n");}

printf ("}}");


