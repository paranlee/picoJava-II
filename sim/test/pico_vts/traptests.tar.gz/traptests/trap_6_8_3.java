//****************************************************************
//***
//***    Copyright 1999 Sun Microsystems, Inc., 901 San Antonio
//***    Road, Palo Alto, CA 94303, U.S.A.  All Rights Reserved.
//***    The contents of this file are subject to the current
//***    version of the Sun Community Source License, picoJava-II
//***    Core ("the License").  You may not use this file except
//***    in compliance with the License.  You may obtain a copy
//***    of the License by searching for "Sun Community Source
//***    License" on the World Wide Web at http://www.sun.com.
//***    See the License for the rights, obligations, and
//***    limitations governing use of the contents of this file.
//***
//***    Sun, Sun Microsystems, the Sun logo, and all Sun-based
//***    trademarks and logos, Java, picoJava, and all Java-based
//***    trademarks and logos are trademarks or registered trademarks
//***    of Sun Microsystems, Inc. in the United States and other
//***    countries.
//***
//*****************************************************************




public class trap_6_8_3 {
 
        static short s;

    public static int main() {

	s = 0;

	switch (s) {
		case 0:		
			s = 1;
			break;
		case 1:		
			s = 2;
			break;
		case 100:
			s = 2;
			break;
		default:	
			s = 2;
	}

        switch (s) {
                case 0:        
                        s = 2;
                        break;
                case 1:        
                        s = 100;
                        break;
                case 100:
                        s = 2;
                        break;
                default:       
                        s = 2;
        }

        switch (s) {
                case 0:        
                        s = 2;
                        break;
                case 1:        
                        s = 2;
                        break;
                case 100:
                        s = 3;
                        break;
                default:       
                        s = 2;
        }

        switch (s) {
                case 0:        
                        s = 2;
                        break;
                case 1:        
                        s = 2;
                        break;
                case 100:
                        s = 2;
                        break;
                default:       
                        s = 0;
        }


	return s;
   }
}

