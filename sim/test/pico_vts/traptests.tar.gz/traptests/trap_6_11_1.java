//****************************************************************
//***
//***    Copyright 1999 Sun Microsystems, Inc., 901 San Antonio
//***    Road, Palo Alto, CA 94303, U.S.A.  All Rights Reserved.
//***    The contents of this file are subject to the current
//***    version of the Sun Community Source License, picoJava-II
//***    Core ("the License").  You may not use this file except
//***    in compliance with the License.  You may obtain a copy
//***    of the License by searching for "Sun Community Source
//***    License" on the World Wide Web at http://www.sun.com.
//***    See the License for the rights, obligations, and
//***    limitations governing use of the contents of this file.
//***
//***    Sun, Sun Microsystems, the Sun logo, and all Sun-based
//***    trademarks and logos, Java, picoJava, and all Java-based
//***    trademarks and logos are trademarks or registered trademarks
//***    of Sun Microsystems, Inc. in the United States and other
//***    countries.
//***
//*****************************************************************




public class trap_6_11_1 {

    static byte[][][] byteArray;

    public static int main() {

	byteArray = new byte[4] [4] [6];

	byteArray[0][0][0] = 111;
	byteArray[1][2][3] = 24;
	byteArray[3][1][4] = 20;
	byteArray[2][3][1] = 12;
	byteArray[3][3][5] = 18;

	if (byteArray[0][0][0] != 111) return 2;
	if (byteArray[1][2][3] != 24) return 2;
	if (byteArray[3][1][4] != 20) return 2;
	if (byteArray[2][3][1] != 12) return 2;
	if (byteArray[3][3][5] != 18) return 2;

	return 0;
    }
}
