//****************************************************************
//***
//***    Copyright 1999 Sun Microsystems, Inc., 901 San Antonio
//***    Road, Palo Alto, CA 94303, U.S.A.  All Rights Reserved.
//***    The contents of this file are subject to the current
//***    version of the Sun Community Source License, picoJava-II
//***    Core ("the License").  You may not use this file except
//***    in compliance with the License.  You may obtain a copy
//***    of the License by searching for "Sun Community Source
//***    License" on the World Wide Web at http://www.sun.com.
//***    See the License for the rights, obligations, and
//***    limitations governing use of the contents of this file.
//***
//***    Sun, Sun Microsystems, the Sun logo, and all Sun-based
//***    trademarks and logos, Java, picoJava, and all Java-based
//***    trademarks and logos are trademarks or registered trademarks
//***    of Sun Microsystems, Inc. in the United States and other
//***    countries.
//***
//*****************************************************************




public class trap_6_2_10 {

	float i1, i2, i3, i4, i5, i6, i7, i8, i9, i10;
	float i11, i12, i13, i14, i15, i16, i17, i18, i19, i20;
	float i21, i22, i23, i24, i25, i26, i27, i28, i29, i30;
	float i31, i32, i33, i34, i35, i36, i37, i38, i39, i40;
	float i41, i42, i43, i44, i45, i46, i47, i48, i49, i50;
	float i51, i52, i53, i54, i55, i56, i57, i58, i59, i60;
	float i61, i62, i63, i64, i65, i66, i67, i68, i69, i70;
	float i71, i72, i73, i74, i75, i76, i77, i78, i79, i80;
	float i81, i82, i83, i84, i85, i86, i87, i88, i89, i90;
	float i91, i92, i93, i94, i95, i96, i97, i98, i99, i100;
        float i101, i102, i103, i104, i105, i106, i107, i108, i109, i110;
        float i111, i112, i113, i114, i115, i116, i117, i118, i119, i120;
        float i121, i122, i123, i124, i125, i126, i127, i128, i129, i130;
        float i131, i132, i133, i134, i135, i136, i137, i138, i139, i140;
        float i141, i142, i143, i144, i145, i146, i147, i148, i149, i150;
        float i151, i152, i153, i154, i155, i156, i157, i158, i159, i160;
        float i161, i162, i163, i164, i165, i166, i167, i168, i169, i170;
        float i171, i172, i173, i174, i175, i176, i177, i178, i179, i180;
        float i181, i182, i183, i184, i185, i186, i187, i188, i189, i190;
        float i191, i192, i193, i194, i195, i196, i197, i198, i199, i200;
        float i201, i202, i203, i204, i205, i206, i207, i208, i209, i210;
        float i211, i212, i213, i214, i215, i216, i217, i218, i219, i220;
        float i221, i222, i223, i224, i225, i226, i227, i228, i229, i230;
        float i231, i232, i233, i234, i235, i236, i237, i238, i239, i240;
        float i241, i242, i243, i244, i245, i246, i247, i248, i249, i250;
        float i251, i252, i253, i254, i255, i256, i257, i258, i259, i260;
        float i261, i262, i263, i264, i265, i266, i267, i268, i269, i270;
        float i271, i272, i273, i274, i275, i276, i277, i278, i279, i280;
        float i281, i282, i283, i284, i285, i286, i287, i288, i289, i290;
        float i291, i292, i293, i294, i295, i296, i297, i298, i299, i300;

    public static int main() {
	trap_6_2_10 p;

	p = new trap_6_2_10();

	p.i1 = 1f;
	p.i254 = 254f;
	p.i255 = 255f;
	p.i256 = 256f;
	p.i300 = 300f;

	if ((p.i1 == 1f) && (p.i254 == 254f) && (p.i255 == 255f) && (p.i256 == 256f) && (p.i300 == 300f))
		return 0x0;
	else 
		return 0x2;
   }
}
