//****************************************************************
//***
//***    Copyright 1999 Sun Microsystems, Inc., 901 San Antonio
//***    Road, Palo Alto, CA 94303, U.S.A.  All Rights Reserved.
//***    The contents of this file are subject to the current
//***    version of the Sun Community Source License, picoJava-II
//***    Core ("the License").  You may not use this file except
//***    in compliance with the License.  You may obtain a copy
//***    of the License by searching for "Sun Community Source
//***    License" on the World Wide Web at http://www.sun.com.
//***    See the License for the rights, obligations, and
//***    limitations governing use of the contents of this file.
//***
//***    Sun, Sun Microsystems, the Sun logo, and all Sun-based
//***    trademarks and logos, Java, picoJava, and all Java-based
//***    trademarks and logos are trademarks or registered trademarks
//***    of Sun Microsystems, Inc. in the United States and other
//***    countries.
//***
//*****************************************************************




public class trap_6_4_12 {
 
        static int i;
 
		void i1(int a) {
		i = a + 1;
		}
		void i2(int a) {
		i = a + 2;
		}
		void i3(int a) {
		i = a + 3;
		}
		void i4(int a) {
		i = a + 4;
		}
		void i5(int a) {
		i = a + 5;
		}
		void i6(int a) {
		i = a + 6;
		}
		void i7(int a) {
		i = a + 7;
		}
		void i8(int a) {
		i = a + 8;
		}
		void i9(int a) {
		i = a + 9;
		}
		void i10(int a) {
		i = a + 10;
		}
		void i11(int a) {
		i = a + 11;
		}
		void i12(int a) {
		i = a + 12;
		}
		void i13(int a) {
		i = a + 13;
		}
		void i14(int a) {
		i = a + 14;
		}
		void i15(int a) {
		i = a + 15;
		}
		void i16(int a) {
		i = a + 16;
		}
		void i17(int a) {
		i = a + 17;
		}
		void i18(int a) {
		i = a + 18;
		}
		void i19(int a) {
		i = a + 19;
		}
		void i20(int a) {
		i = a + 20;
		}
		void i21(int a) {
		i = a + 21;
		}
		void i22(int a) {
		i = a + 22;
		}
		void i23(int a) {
		i = a + 23;
		}
		void i24(int a) {
		i = a + 24;
		}
		void i25(int a) {
		i = a + 25;
		}
		void i26(int a) {
		i = a + 26;
		}
		void i27(int a) {
		i = a + 27;
		}
		void i28(int a) {
		i = a + 28;
		}
		void i29(int a) {
		i = a + 29;
		}
		void i30(int a) {
		i = a + 30;
		}
		void i31(int a) {
		i = a + 31;
		}
		void i32(int a) {
		i = a + 32;
		}
		void i33(int a) {
		i = a + 33;
		}
		void i34(int a) {
		i = a + 34;
		}
		void i35(int a) {
		i = a + 35;
		}
		void i36(int a) {
		i = a + 36;
		}
		void i37(int a) {
		i = a + 37;
		}
		void i38(int a) {
		i = a + 38;
		}
		void i39(int a) {
		i = a + 39;
		}
		void i40(int a) {
		i = a + 40;
		}
		void i41(int a) {
		i = a + 41;
		}
		void i42(int a) {
		i = a + 42;
		}
		void i43(int a) {
		i = a + 43;
		}
		void i44(int a) {
		i = a + 44;
		}
		void i45(int a) {
		i = a + 45;
		}
		void i46(int a) {
		i = a + 46;
		}
		void i47(int a) {
		i = a + 47;
		}
		void i48(int a) {
		i = a + 48;
		}
		void i49(int a) {
		i = a + 49;
		}
		void i50(int a) {
		i = a + 50;
		}
		void i51(int a) {
		i = a + 51;
		}
		void i52(int a) {
		i = a + 52;
		}
		void i53(int a) {
		i = a + 53;
		}
		void i54(int a) {
		i = a + 54;
		}
		void i55(int a) {
		i = a + 55;
		}
		void i56(int a) {
		i = a + 56;
		}
		void i57(int a) {
		i = a + 57;
		}
		void i58(int a) {
		i = a + 58;
		}
		void i59(int a) {
		i = a + 59;
		}
		void i60(int a) {
		i = a + 60;
		}
		void i61(int a) {
		i = a + 61;
		}
		void i62(int a) {
		i = a + 62;
		}
		void i63(int a) {
		i = a + 63;
		}
		void i64(int a) {
		i = a + 64;
		}
		void i65(int a) {
		i = a + 65;
		}
		void i66(int a) {
		i = a + 66;
		}
		void i67(int a) {
		i = a + 67;
		}
		void i68(int a) {
		i = a + 68;
		}
		void i69(int a) {
		i = a + 69;
		}
		void i70(int a) {
		i = a + 70;
		}
		void i71(int a) {
		i = a + 71;
		}
		void i72(int a) {
		i = a + 72;
		}
		void i73(int a) {
		i = a + 73;
		}
		void i74(int a) {
		i = a + 74;
		}
		void i75(int a) {
		i = a + 75;
		}
		void i76(int a) {
		i = a + 76;
		}
		void i77(int a) {
		i = a + 77;
		}
		void i78(int a) {
		i = a + 78;
		}
		void i79(int a) {
		i = a + 79;
		}
		void i80(int a) {
		i = a + 80;
		}
		void i81(int a) {
		i = a + 81;
		}
		void i82(int a) {
		i = a + 82;
		}
		void i83(int a) {
		i = a + 83;
		}
		void i84(int a) {
		i = a + 84;
		}
		void i85(int a) {
		i = a + 85;
		}
		void i86(int a) {
		i = a + 86;
		}
		void i87(int a) {
		i = a + 87;
		}
		void i88(int a) {
		i = a + 88;
		}
		void i89(int a) {
		i = a + 89;
		}
		void i90(int a) {
		i = a + 90;
		}
		void i91(int a) {
		i = a + 91;
		}
		void i92(int a) {
		i = a + 92;
		}
		void i93(int a) {
		i = a + 93;
		}
		void i94(int a) {
		i = a + 94;
		}
		void i95(int a) {
		i = a + 95;
		}
		void i96(int a) {
		i = a + 96;
		}
		void i97(int a) {
		i = a + 97;
		}
		void i98(int a) {
		i = a + 98;
		}
		void i99(int a) {
		i = a + 99;
		}
		void i100(int a) {
		i = a + 100;
		}
		void i101(int a) {
		i = a + 101;
		}
		void i102(int a) {
		i = a + 102;
		}
		void i103(int a) {
		i = a + 103;
		}
		void i104(int a) {
		i = a + 104;
		}
		void i105(int a) {
		i = a + 105;
		}
		void i106(int a) {
		i = a + 106;
		}
		void i107(int a) {
		i = a + 107;
		}
		void i108(int a) {
		i = a + 108;
		}
		void i109(int a) {
		i = a + 109;
		}
		void i110(int a) {
		i = a + 110;
		}
		void i111(int a) {
		i = a + 111;
		}
		void i112(int a) {
		i = a + 112;
		}
		void i113(int a) {
		i = a + 113;
		}
		void i114(int a) {
		i = a + 114;
		}
		void i115(int a) {
		i = a + 115;
		}
		void i116(int a) {
		i = a + 116;
		}
		void i117(int a) {
		i = a + 117;
		}
		void i118(int a) {
		i = a + 118;
		}
		void i119(int a) {
		i = a + 119;
		}
		void i120(int a) {
		i = a + 120;
		}
		void i121(int a) {
		i = a + 121;
		}
		void i122(int a) {
		i = a + 122;
		}
		void i123(int a) {
		i = a + 123;
		}
		void i124(int a) {
		i = a + 124;
		}
		void i125(int a) {
		i = a + 125;
		}
		void i126(int a) {
		i = a + 126;
		}
		void i127(int a) {
		i = a + 127;
		}
		void i128(int a) {
		i = a + 128;
		}
		void i129(int a) {
		i = a + 129;
		}
		void i130(int a) {
		i = a + 130;
		}
		void i131(int a) {
		i = a + 131;
		}
		void i132(int a) {
		i = a + 132;
		}
		void i133(int a) {
		i = a + 133;
		}
		void i134(int a) {
		i = a + 134;
		}
		void i135(int a) {
		i = a + 135;
		}
		void i136(int a) {
		i = a + 136;
		}
		void i137(int a) {
		i = a + 137;
		}
		void i138(int a) {
		i = a + 138;
		}
		void i139(int a) {
		i = a + 139;
		}
		void i140(int a) {
		i = a + 140;
		}
		void i141(int a) {
		i = a + 141;
		}
		void i142(int a) {
		i = a + 142;
		}
		void i143(int a) {
		i = a + 143;
		}
		void i144(int a) {
		i = a + 144;
		}
		void i145(int a) {
		i = a + 145;
		}
		void i146(int a) {
		i = a + 146;
		}
		void i147(int a) {
		i = a + 147;
		}
		void i148(int a) {
		i = a + 148;
		}
		void i149(int a) {
		i = a + 149;
		}
		void i150(int a) {
		i = a + 150;
		}
		void i151(int a) {
		i = a + 151;
		}
		void i152(int a) {
		i = a + 152;
		}
		void i153(int a) {
		i = a + 153;
		}
		void i154(int a) {
		i = a + 154;
		}
		void i155(int a) {
		i = a + 155;
		}
		void i156(int a) {
		i = a + 156;
		}
		void i157(int a) {
		i = a + 157;
		}
		void i158(int a) {
		i = a + 158;
		}
		void i159(int a) {
		i = a + 159;
		}
		void i160(int a) {
		i = a + 160;
		}
		void i161(int a) {
		i = a + 161;
		}
		void i162(int a) {
		i = a + 162;
		}
		void i163(int a) {
		i = a + 163;
		}
		void i164(int a) {
		i = a + 164;
		}
		void i165(int a) {
		i = a + 165;
		}
		void i166(int a) {
		i = a + 166;
		}
		void i167(int a) {
		i = a + 167;
		}
		void i168(int a) {
		i = a + 168;
		}
		void i169(int a) {
		i = a + 169;
		}
		void i170(int a) {
		i = a + 170;
		}
		void i171(int a) {
		i = a + 171;
		}
		void i172(int a) {
		i = a + 172;
		}
		void i173(int a) {
		i = a + 173;
		}
		void i174(int a) {
		i = a + 174;
		}
		void i175(int a) {
		i = a + 175;
		}
		void i176(int a) {
		i = a + 176;
		}
		void i177(int a) {
		i = a + 177;
		}
		void i178(int a) {
		i = a + 178;
		}
		void i179(int a) {
		i = a + 179;
		}
		void i180(int a) {
		i = a + 180;
		}
		void i181(int a) {
		i = a + 181;
		}
		void i182(int a) {
		i = a + 182;
		}
		void i183(int a) {
		i = a + 183;
		}
		void i184(int a) {
		i = a + 184;
		}
		void i185(int a) {
		i = a + 185;
		}
		void i186(int a) {
		i = a + 186;
		}
		void i187(int a) {
		i = a + 187;
		}
		void i188(int a) {
		i = a + 188;
		}
		void i189(int a) {
		i = a + 189;
		}
		void i190(int a) {
		i = a + 190;
		}
		void i191(int a) {
		i = a + 191;
		}
		void i192(int a) {
		i = a + 192;
		}
		void i193(int a) {
		i = a + 193;
		}
		void i194(int a) {
		i = a + 194;
		}
		void i195(int a) {
		i = a + 195;
		}
		void i196(int a) {
		i = a + 196;
		}
		void i197(int a) {
		i = a + 197;
		}
		void i198(int a) {
		i = a + 198;
		}
		void i199(int a) {
		i = a + 199;
		}
		void i200(int a) {
		i = a + 200;
		}
		void i201(int a) {
		i = a + 201;
		}
		void i202(int a) {
		i = a + 202;
		}
		void i203(int a) {
		i = a + 203;
		}
		void i204(int a) {
		i = a + 204;
		}
		void i205(int a) {
		i = a + 205;
		}
		void i206(int a) {
		i = a + 206;
		}
		void i207(int a) {
		i = a + 207;
		}
		void i208(int a) {
		i = a + 208;
		}
		void i209(int a) {
		i = a + 209;
		}
		void i210(int a) {
		i = a + 210;
		}
		void i211(int a) {
		i = a + 211;
		}
		void i212(int a) {
		i = a + 212;
		}
		void i213(int a) {
		i = a + 213;
		}
		void i214(int a) {
		i = a + 214;
		}
		void i215(int a) {
		i = a + 215;
		}
		void i216(int a) {
		i = a + 216;
		}
		void i217(int a) {
		i = a + 217;
		}
		void i218(int a) {
		i = a + 218;
		}
		void i219(int a) {
		i = a + 219;
		}
		void i220(int a) {
		i = a + 220;
		}
		void i221(int a) {
		i = a + 221;
		}
		void i222(int a) {
		i = a + 222;
		}
		void i223(int a) {
		i = a + 223;
		}
		void i224(int a) {
		i = a + 224;
		}
		void i225(int a) {
		i = a + 225;
		}
		void i226(int a) {
		i = a + 226;
		}
		void i227(int a) {
		i = a + 227;
		}
		void i228(int a) {
		i = a + 228;
		}
		void i229(int a) {
		i = a + 229;
		}
		void i230(int a) {
		i = a + 230;
		}
		void i231(int a) {
		i = a + 231;
		}
		void i232(int a) {
		i = a + 232;
		}
		void i233(int a) {
		i = a + 233;
		}
		void i234(int a) {
		i = a + 234;
		}
		void i235(int a) {
		i = a + 235;
		}
		void i236(int a) {
		i = a + 236;
		}
		void i237(int a) {
		i = a + 237;
		}
		void i238(int a) {
		i = a + 238;
		}
		void i239(int a) {
		i = a + 239;
		}
		void i240(int a) {
		i = a + 240;
		}
		void i241(int a) {
		i = a + 241;
		}
		void i242(int a) {
		i = a + 242;
		}
		void i243(int a) {
		i = a + 243;
		}
		void i244(int a) {
		i = a + 244;
		}
		void i245(int a) {
		i = a + 245;
		}
		void i246(int a) {
		i = a + 246;
		}
		void i247(int a) {
		i = a + 247;
		}
		void i248(int a) {
		i = a + 248;
		}
		void i249(int a) {
		i = a + 249;
		}
		void i250(int a) {
		i = a + 250;
		}
		void i251(int a) {
		i = a + 251;
		}
		void i252(int a) {
		i = a + 252;
		}
		void i253(int a) {
		i = a + 253;
		}
		void i254(int a) {
		i = a + 254;
		}
		void i255(int a) {
		i = a + 255;
		}
		void i256(int a) {
		i = a + 256;
		}
		void i257(int a) {
		i = a + 257;
		}
		void i258(int a) {
		i = a + 258;
		}
		void i259(int a) {
		i = a + 259;
		}
		void i260(int a) {
		i = a + 260;
		}
		void i261(int a) {
		i = a + 261;
		}
		void i262(int a) {
		i = a + 262;
		}
		void i263(int a) {
		i = a + 263;
		}
		void i264(int a) {
		i = a + 264;
		}
		void i265(int a) {
		i = a + 265;
		}
		void i266(int a) {
		i = a + 266;
		}
		void i267(int a) {
		i = a + 267;
		}
		void i268(int a) {
		i = a + 268;
		}
		void i269(int a) {
		i = a + 269;
		}
		void i270(int a) {
		i = a + 270;
		}
		void i271(int a) {
		i = a + 271;
		}
		void i272(int a) {
		i = a + 272;
		}
		void i273(int a) {
		i = a + 273;
		}
		void i274(int a) {
		i = a + 274;
		}
		void i275(int a) {
		i = a + 275;
		}
		void i276(int a) {
		i = a + 276;
		}
		void i277(int a) {
		i = a + 277;
		}
		void i278(int a) {
		i = a + 278;
		}
		void i279(int a) {
		i = a + 279;
		}
		void i280(int a) {
		i = a + 280;
		}
		void i281(int a) {
		i = a + 281;
		}
		void i282(int a) {
		i = a + 282;
		}
		void i283(int a) {
		i = a + 283;
		}
		void i284(int a) {
		i = a + 284;
		}
		void i285(int a) {
		i = a + 285;
		}
		void i286(int a) {
		i = a + 286;
		}
		void i287(int a) {
		i = a + 287;
		}
		void i288(int a) {
		i = a + 288;
		}
		void i289(int a) {
		i = a + 289;
		}
		void i290(int a) {
		i = a + 290;
		}
		void i291(int a) {
		i = a + 291;
		}
		void i292(int a) {
		i = a + 292;
		}
		void i293(int a) {
		i = a + 293;
		}
		void i294(int a) {
		i = a + 294;
		}
		void i295(int a) {
		i = a + 295;
		}
		void i296(int a) {
		i = a + 296;
		}
		void i297(int a) {
		i = a + 297;
		}
		void i298(int a) {
		i = a + 298;
		}
		void i299(int a) {
		i = a + 299;
		}
		void i300(int a) {
		i = a + 300;
		}

        static int main() {
 
                trap_6_4_12 s = new trap_6_4_12();
 
                s.i1(1);
 
                if (i != 2)
                        return 2;
 
                s.i300(300);
 
                if (i == 600)
                        return 0;
                else
                        return 2;
 
        }

}
