//****************************************************************
//***
//***    Copyright 1999 Sun Microsystems, Inc., 901 San Antonio
//***    Road, Palo Alto, CA 94303, U.S.A.  All Rights Reserved.
//***    The contents of this file are subject to the current
//***    version of the Sun Community Source License, picoJava-II
//***    Core ("the License").  You may not use this file except
//***    in compliance with the License.  You may obtain a copy
//***    of the License by searching for "Sun Community Source
//***    License" on the World Wide Web at http://www.sun.com.
//***    See the License for the rights, obligations, and
//***    limitations governing use of the contents of this file.
//***
//***    Sun, Sun Microsystems, the Sun logo, and all Sun-based
//***    trademarks and logos, Java, picoJava, and all Java-based
//***    trademarks and logos are trademarks or registered trademarks
//***    of Sun Microsystems, Inc. in the United States and other
//***    countries.
//***
//*****************************************************************




public class trap_6_7_2{ 

    static int i0, i1, i2, i3, i4, i5, i6, i7, i8, i9, ia, ib, ic, id, ie, iif;

    static int j0, j1, j2, j3, j4, j5, j6, j7, j8, j9, ja, jb, jc, jd, je, jf;

    static int k0, k1, k2, k3, k4, k5, k6, k7, k8, k9, ka, kb, kc, kd, ke, kf;

    static int l0, l1, l2, l3, l4, l5, l6, l7, l8, l9, la, lb, lc, ld, le, lf;

    static int m0, m1, m2, m3, m4, m5, m6, m7, m8, m9, ma, mb, mc, md, me, mf;

    static int n0, n1, n2, n3, n4, n5, n6, n7, n8, n9, na, nb, nc, nd, ne, nf;

    static int o0, o1, o2, o3, o4, o5, o6, o7, o8, o9, oa, ob, oc, od, oe, of;

    static int p0, p1, p2, p3, p4, p5, p6, p7, p8, p9, pa, pb, pc, pd, pe, pf;

    static int q0, q1, q2, q3, q4, q5, q6, q7, q8, q9, qa, qb, qc, qd, qe, qf;

    static int r0, r1, r2, r3, r4, r5, r6, r7, r8, r9, ra, rb, rc, rd, re, rf;

    static int s0, s1, s2, s3, s4, s5, s6, s7, s8, s9, sa, sb, sc, sd, se, sf;

    static int t0, t1, t2, t3, t4, t5, t6, t7, t8, t9, ta, tb, tc, td, te, tf;

    static int u0, u1, u2, u3, u4, u5, u6, u7, u8, u9, ua, ub, uc, ud, ue, uf;

    static int v0, v1, v2, v3, v4, v5, v6, v7, v8, v9, va, vb, vc, vd, ve, vf;

    static int w0, w1, w2, w3, w4, w5, w6, w7, w8, w9, wa, wb, wc, wd, we, wf;

    static int x0, x1, x2, x3, x4, x5, x6, x7, x8, x9, xa, xb, xc, xd, xe, xf;

    public static int main() {

	int condition = 0;
	
	if(condition == 1) {

    	i0= 0xA010; i1= 0xA011; i2= 0xA012; i3= 0xA013; i4= 0xA014;
	i5= 0xA015; i6= 0xA016; i7= 0xA017; i8= 0xA018; i9= 0xA019;
	ia= 0xA01a; ib= 0xA01b; ic= 0xA01c; id= 0xA01d; ie= 0xA01e; iif= 0xA01f;

	j0= 0xA020; j1= 0xA021; j2= 0xA022; j3= 0xA023; j4= 0xA024;
	j5= 0xA025; j6= 0xA026; j7= 0xA027; j8= 0xA028; j9= 0xA029;
	ja= 0xA02a; jb= 0xA02b; jc= 0xA02c; jd= 0xA02d; je= 0xA02e; jf= 0xA02f;

	k0= 0xA030; k1= 0xA031; k2= 0xA032; k3= 0xA033; k4= 0xA034;
	k5= 0xA035; k6= 0xA036; k7= 0xA037; k8= 0xA038; k9= 0xA039;
	ka= 0xA03a; kb= 0xA03b; kc= 0xA03c; kd= 0xA03d; ke= 0xA03e; kf= 0xA03f;

	l0= 0xA040; l1= 0xA041; l2= 0xA042; l3= 0xA043; l4= 0xA044;
	l5= 0xA045; l6= 0xA046; l7= 0xA047; l8= 0xA048; l9= 0xA049;
	la= 0xA04a; lb= 0xA04b; lc= 0xA04c; ld= 0xA04d; le= 0xA04e; lf=0xA04f;

	m0= 0xA050; m1= 0xA051; m2= 0xA052; m3= 0xA053; m4= 0xA054;
	m5= 0xA055; m6= 0xA056; m7= 0xA057; m8= 0xA058; m9= 0xA059;
	ma= 0xA05a; mb= 0xA05b; mc= 0xA05c; md= 0xA05d; me= 0xA05e; mf=0xA05f;

	n0= 0xA060; n1= 0xA061; n2= 0xA062; n3= 0xA063; n4= 0xA064;
	n5= 0xA065; n6= 0xA066; n7= 0xA067; n8= 0xA068; n9= 0xA069;
	na= 0xA06a; nb= 0xA06b; nc= 0xA06c; nd= 0xA06d; ne= 0xA06e; nf=0xA06f;

	o0= 0xA070; o1= 0xA071; o2= 0xA072; o3= 0xA073; o4= 0xA074;
	o5= 0xA075; o6= 0xA076; o7= 0xA077; o8= 0xA078; o9= 0xA079;
	oa= 0xA07a; ob= 0xA07b; oc= 0xA07c; od= 0xA07d; oe= 0xA07e; of= 0xA07f;

	p0= 0xA080; p1= 0xA081; p2= 0xA082; p3= 0xA083; p4= 0xA084;
	p5= 0xA085; p6= 0xA086; p7= 0xA087; p8= 0xA088; p9= 0xA089;
	pa= 0xA08a; pb= 0xA08b; pc= 0xA08c; pd= 0xA08d; pe= 0xA08e; pf=0xA08f;

	q0= 0xA090; q1= 0xA091; q2= 0xA092; q3= 0xA093; q4= 0xA094;
	q5= 0xA095; q6= 0xA096; q7= 0xA097; q8= 0xA098; q9= 0xA099;
	qa= 0xA09a; qb= 0xA09b; qc= 0xA09c; qd= 0xA09d; qe= 0xA09e; qf=0xA09f;

	r0= 0xA0A0; r1= 0xA0A1; r2= 0xA0A2; r3= 0xA0A3; r4= 0xA0A4;
	r5= 0xA0A5; r6= 0xA0A6; r7= 0xA0A7; r8= 0xA0A8; r9= 0xA0A9;
	ra= 0xA0Aa; rb= 0xA0Ab; rc= 0xA0Ac; rd= 0xA0Ad; re= 0xA0Ae; rf=0xA0Af;

	s0= 0xA0B0; s1= 0xA0B1; s2= 0xA0B2; s3= 0xA0B3; s4= 0xA0B4;
	s5= 0xA0B5; s6= 0xA0B6; s7= 0xA0B7; s8= 0xA0B8; s9= 0xA0B9;
	sa= 0xA0Ba; sb= 0xA0Bb; sc= 0xA0Bc; sd= 0xA0Bd; se= 0xA0Be; sf= 0xA0Bf;

	t0= 0xA0C0; t1= 0xA0C1; t2= 0xA0C2; t3= 0xA0C3; t4= 0xA0C4;
	t5= 0xA0C5; t6= 0xA0C6; t7= 0xA0C7; t8= 0xA0C8; t9= 0xA0C9;
	ta= 0xA0Ca; tb= 0xA0Cb; tc= 0xA0Cc; td= 0xA0Cd; te= 0xA0Ce; tf= 0xA0Cf;

	u0= 0xA0D0; u1= 0xA0D1; u2= 0xA0D2; u3= 0xA0D3; u4= 0xA0D4;
	u5= 0xA0D5; u6= 0xA0D6; u7= 0xA0D7; u8= 0xA0D8; u9= 0xA0D9;
	ua= 0xA0Da; ub= 0xA0Db; uc= 0xA0Dc; ud= 0xA0Dd; ue= 0xA0De; uf= 0xA0df;

	v0= 0xA0E0; v1= 0xA0E1; v2= 0xA0E2; v3= 0xA0E3; v4= 0xA0E4;
	v5= 0xA0E5; v6= 0xA0E6; v7= 0xA0E7; v8= 0xA0E8; v9= 0xA0E9;
	va= 0xA0Ea; vb= 0xA0Eb; vc= 0xA0Ec; vd= 0xA0Ed; ve= 0xA0Ee; vf= 0xA0Ef;

	w0= 0xA0F0; w1= 0xA0F1; w2= 0xA0F2; w3= 0xA0F3; w4= 0xA0F4;
	w5= 0xA0F5; w6= 0xA0F6; w7= 0xA0F7; w8= 0xA0F8; w9= 0xA0F9;
	wa= 0xA0Fa; wb= 0xA0Fb; wc= 0xA0Fc; wd= 0xA0Fd; we= 0xA0Fe; wf= 0xA0Ff;

	x0= 0xA100; x1= 0xA101; x2= 0xA102; x3= 0xA103; x4= 0xA104;
	x5= 0xA105; x6= 0xA106; x7= 0xA107; x8= 0xA108; x9= 0xA109;
	xa= 0xA10a; xb= 0xA10b; xc= 0xA10c; xd= 0xA10d; xe= 0xA10e; xf= 0xA010f;

	i2 = 0xabcd;
	}
	else {
	i0 = 0xA010;
	i1 = 0xA011;
	i2 = 0xabcd;
	xf = 0xA010f;
	}

	if ((i0 == 0xA010) && (i1 == 0xA011) && (i2 == 0xabcd) && (xf == 0xA010f))
		return 0x0;
	else 
		return 2;

    }
}
