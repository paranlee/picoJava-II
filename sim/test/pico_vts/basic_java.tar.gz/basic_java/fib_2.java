//****************************************************************
//***
//***    Copyright 1999 Sun Microsystems, Inc., 901 San Antonio
//***    Road, Palo Alto, CA 94303, U.S.A.  All Rights Reserved.
//***    The contents of this file are subject to the current
//***    version of the Sun Community Source License, picoJava-II
//***    Core ("the License").  You may not use this file except
//***    in compliance with the License.  You may obtain a copy
//***    of the License by searching for "Sun Community Source
//***    License" on the World Wide Web at http://www.sun.com.
//***    See the License for the rights, obligations, and
//***    limitations governing use of the contents of this file.
//***
//***    Sun, Sun Microsystems, the Sun logo, and all Sun-based
//***    trademarks and logos, Java, picoJava, and all Java-based
//***    trademarks and logos are trademarks or registered trademarks
//***    of Sun Microsystems, Inc. in the United States and other
//***    countries.
//***
//*****************************************************************



class fib_2 {
  public static int fib (int n) {
    int x, y, z;
    y = 1;
    z = 2;
    if (n == 1)
      return 1;
    else if (n == 2)
      return 1;
    else {
      if (z != 2) return 0;
      x = fib(n-1);
      if (z != 2) return 0;
      if (y != 1) return 0;
      return fib(n-2) + x;
    }
  }

  public static int main() {
    if (fib(8) != 21)
      return 2;
    else
      return 0;
  }
}
