//****************************************************************
//***
//***    Copyright 1999 Sun Microsystems, Inc., 901 San Antonio
//***    Road, Palo Alto, CA 94303, U.S.A.  All Rights Reserved.
//***    The contents of this file are subject to the current
//***    version of the Sun Community Source License, picoJava-II
//***    Core ("the License").  You may not use this file except
//***    in compliance with the License.  You may obtain a copy
//***    of the License by searching for "Sun Community Source
//***    License" on the World Wide Web at http://www.sun.com.
//***    See the License for the rights, obligations, and
//***    limitations governing use of the contents of this file.
//***
//***    Sun, Sun Microsystems, the Sun logo, and all Sun-based
//***    trademarks and logos, Java, picoJava, and all Java-based
//***    trademarks and logos are trademarks or registered trademarks
//***    of Sun Microsystems, Inc. in the United States and other
//***    countries.
//***
//*****************************************************************



class invoking_banana extends fruit {

   
   char ctry_code;
   private int length;
   double diameter;
   long calories;
   String color;

   invoking_banana(char cty, int l, double d, String clr){
     ctry_code = cty;
     length = l;
     diameter = d;
     color = clr;
   }

  private void growLonger() { length = length + 1; } 
  public void decrementLife() {super.decrementLife(); return;}  

  boolean isLengthOne1() { if (length == 1) return true; return false; } 
  boolean isLengthOne2() { if (length == 1) return true; return false; }
  boolean isLengthOne3() { if (length == 1) return true; return false; }
  boolean isLengthOne4() { if (length == 1) return true; return false; }
  boolean isLengthOne5() { if (length == 1) return true; return false; }
  boolean isLengthOne6() { if (length == 1) return true; return false; }
  boolean isLengthOne7() { if (length == 1) return true; return false; }
  boolean isLengthOne8() { if (length == 1) return true; return false; }
  boolean isLengthOne9() { if (length == 1) return true; return false; }
  boolean isLengthOne10() { if (length == 1) return true; return false; }
  boolean isLengthOne11() { if (length == 1) return true; return false; }
  boolean isLengthOne12() { if (length == 1) return true; return false; }
  boolean isLengthOne13() { if (length == 1) return true; return false; }
  boolean isLengthOne14() { if (length == 1) return true; return false; }
  boolean isLengthOne15() { if (length == 1) return true; return false; }
  boolean isLengthOne16() { if (length == 1) return true; return false; }
  boolean isLengthOne17() { if (length == 1) return true; return false; }
  boolean isLengthOne18() { if (length == 1) return true; return false; }
  boolean isLengthOne19() { if (length == 1) return true; return false; }
  boolean isLengthOne20() { if (length == 1) return true; return false; }
  boolean isLengthOne21() { if (length == 1) return true; return false; }
  boolean isLengthOne22() { if (length == 1) return true; return false; }
  boolean isLengthOne23() { if (length == 1) return true; return false; }
  boolean isLengthOne24() { if (length == 1) return true; return false; }
  boolean isLengthOne25() { if (length == 1) return true; return false; }
  boolean isLengthOne26() { if (length == 1) return true; return false; }
  boolean isLengthOne27() { if (length == 1) return true; return false; }
  boolean isLengthOne28() { if (length == 1) return true; return false; }
  boolean isLengthOne29() { if (length == 1) return true; return false; }
  boolean isLengthOne30() { if (length == 1) return true; return false; }
  boolean isLengthOne31() { if (length == 1) return true; return false; }
  boolean isLengthOne32() { if (length == 1) return true; return false; }
  boolean isLengthOne33() { if (length == 1) return true; return false; }
  boolean isLengthOne34() { if (length == 1) return true; return false; }
  boolean isLengthOne35() { if (length == 1) return true; return false; }
  boolean isLengthOne36() { if (length == 1) return true; return false; }
  boolean isLengthOne37() { if (length == 1) return true; return false; }
  boolean isLengthOne38() { if (length == 1) return true; return false; }
  boolean isLengthOne39() { if (length == 1) return true; return false; }
  boolean isLengthOne40() { if (length == 1) return true; return false; }
  boolean isLengthOne41() { if (length == 1) return true; return false; }
  boolean isLengthOne42() { if (length == 1) return true; return false; }
  boolean isLengthOne43() { if (length == 1) return true; return false; }
  boolean isLengthOne44() { if (length == 1) return true; return false; }
  boolean isLengthOne45() { if (length == 1) return true; return false; }
  boolean isLengthOne46() { if (length == 1) return true; return false; }
  boolean isLengthOne47() { if (length == 1) return true; return false; }
  boolean isLengthOne48() { if (length == 1) return true; return false; }
  boolean isLengthOne49() { if (length == 1) return true; return false; }
  boolean isLengthOne50() { if (length == 1) return true; return false; }
  boolean isLengthOne51() { if (length == 1) return true; return false; }
  boolean isLengthOne52() { if (length == 1) return true; return false; }
  boolean isLengthOne53() { if (length == 1) return true; return false; }
  boolean isLengthOne54() { if (length == 1) return true; return false; }
  boolean isLengthOne55() { if (length == 1) return true; return false; }
  boolean isLengthOne56() { if (length == 1) return true; return false; }
  boolean isLengthOne57() { if (length == 1) return true; return false; }
  boolean isLengthOne58() { if (length == 1) return true; return false; }
  boolean isLengthOne59() { if (length == 1) return true; return false; }
  boolean isLengthOne60() { if (length == 1) return true; return false; }
  boolean isLengthOne61() { if (length == 1) return true; return false; }
  boolean isLengthOne62() { if (length == 1) return true; return false; }
  boolean isLengthOne63() { if (length == 1) return true; return false; }
  boolean isLengthOne64() { if (length == 1) return true; return false; }
  boolean isLengthOne65() { if (length == 1) return true; return false; }
  boolean isLengthOne66() { if (length == 1) return true; return false; }
  boolean isLengthOne67() { if (length == 1) return true; return false; }
  boolean isLengthOne68() { if (length == 1) return true; return false; }
  boolean isLengthOne69() { if (length == 1) return true; return false; }
  boolean isLengthOne70() { if (length == 1) return true; return false; }
  boolean isLengthOne71() { if (length == 1) return true; return false; }
  boolean isLengthOne72() { if (length == 1) return true; return false; }
  boolean isLengthOne73() { if (length == 1) return true; return false; }
  boolean isLengthOne74() { if (length == 1) return true; return false; }
  boolean isLengthOne75() { if (length == 1) return true; return false; }
  boolean isLengthOne76() { if (length == 1) return true; return false; }
  boolean isLengthOne77() { if (length == 1) return true; return false; }
  boolean isLengthOne78() { if (length == 1) return true; return false; }
  boolean isLengthOne79() { if (length == 1) return true; return false; }
  boolean isLengthOne80() { if (length == 1) return true; return false; }
  boolean isLengthOne81() { if (length == 1) return true; return false; }
  boolean isLengthOne82() { if (length == 1) return true; return false; }
  boolean isLengthOne83() { if (length == 1) return true; return false; }
  boolean isLengthOne84() { if (length == 1) return true; return false; }
  boolean isLengthOne85() { if (length == 1) return true; return false; }
  boolean isLengthOne86() { if (length == 1) return true; return false; }
  boolean isLengthOne87() { if (length == 1) return true; return false; }
  boolean isLengthOne88() { if (length == 1) return true; return false; }
  boolean isLengthOne89() { if (length == 1) return true; return false; }
  boolean isLengthOne90() { if (length == 1) return true; return false; }
  boolean isLengthOne91() { if (length == 1) return true; return false; }
  boolean isLengthOne92() { if (length == 1) return true; return false; }
  boolean isLengthOne93() { if (length == 1) return true; return false; }
  boolean isLengthOne94() { if (length == 1) return true; return false; }
  boolean isLengthOne95() { if (length == 1) return true; return false; }
  boolean isLengthOne96() { if (length == 1) return true; return false; }
  boolean isLengthOne97() { if (length == 1) return true; return false; }
  boolean isLengthOne98() { if (length == 1) return true; return false; }
  boolean isLengthOne99() { if (length == 1) return true; return false; }
  boolean isLengthOne100() { if (length == 1) return true; return false; }
  boolean isLengthOne101() { if (length == 1) return true; return false; }
  boolean isLengthOne102() { if (length == 1) return true; return false; }
  boolean isLengthOne103() { if (length == 1) return true; return false; }
  boolean isLengthOne104() { if (length == 1) return true; return false; }
  boolean isLengthOne105() { if (length == 1) return true; return false; }
  boolean isLengthOne106() { if (length == 1) return true; return false; }
  boolean isLengthOne107() { if (length == 1) return true; return false; }
  boolean isLengthOne109() { if (length == 1) return true; return false; }
  boolean isLengthOne110() { if (length == 1) return true; return false; }
  boolean isLengthOne111() { if (length == 1) return true; return false; }
  boolean isLengthOne112() { if (length == 1) return true; return false; }
  boolean isLengthOne113() { if (length == 1) return true; return false; }
  boolean isLengthOne114() { if (length == 1) return true; return false; }
  boolean isLengthOne115() { if (length == 1) return true; return false; }
  boolean isLengthOne116() { if (length == 1) return true; return false; }
  boolean isLengthOne117() { if (length == 1) return true; return false; }
  boolean isLengthOne118() { if (length == 1) return true; return false; }
  boolean isLengthOne119() { if (length == 1) return true; return false; }
  boolean isLengthOne120() { if (length == 1) return true; return false; }
  boolean isLengthOne121() { if (length == 1) return true; return false; }
  boolean isLengthOne122() { if (length == 1) return true; return false; }
  boolean isLengthOne123() { if (length == 1) return true; return false; }
  boolean isLengthOne124() { if (length == 1) return true; return false; }
  boolean isLengthOne125() { if (length == 1) return true; return false; }
  boolean isLengthOne126() { if (length == 1) return true; return false; }
  boolean isLengthOne127() { if (length == 1) return true; return false; }
  boolean isLengthOne128() { if (length == 1) return true; return false; }
  boolean isLengthOne129() { if (length == 1) return true; return false; }
  boolean isLengthOne130() { if (length == 1) return true; return false; }
  boolean isLengthOne131() { if (length == 1) return true; return false; }
  boolean isLengthOne132() { if (length == 1) return true; return false; }
  boolean isLengthOne133() { if (length == 1) return true; return false; }
  boolean isLengthOne134() { if (length == 1) return true; return false; }
  boolean isLengthOne135() { if (length == 1) return true; return false; }
  boolean isLengthOne136() { if (length == 1) return true; return false; }
  boolean isLengthOne137() { if (length == 1) return true; return false; }
  boolean isLengthOne138() { if (length == 1) return true; return false; }
  boolean isLengthOne139() { if (length == 1) return true; return false; }
  boolean isLengthOne140() { if (length == 1) return true; return false; }
  boolean isLengthOne141() { if (length == 1) return true; return false; }
  boolean isLengthOne142() { if (length == 1) return true; return false; }
  boolean isLengthOne143() { if (length == 1) return true; return false; }
  boolean isLengthOne144() { if (length == 1) return true; return false; }
  boolean isLengthOne145() { if (length == 1) return true; return false; }
  boolean isLengthOne146() { if (length == 1) return true; return false; }
  boolean isLengthOne147() { if (length == 1) return true; return false; }
  boolean isLengthOne148() { if (length == 1) return true; return false; }
  boolean isLengthOne149() { if (length == 1) return true; return false; }
  boolean isLengthOne150() { if (length == 1) return true; return false; }
  boolean isLengthOne151() { if (length == 1) return true; return false; }
  boolean isLengthOne152() { if (length == 1) return true; return false; }
  boolean isLengthOne153() { if (length == 1) return true; return false; }
  boolean isLengthOne154() { if (length == 1) return true; return false; }
  boolean isLengthOne155() { if (length == 1) return true; return false; }
  boolean isLengthOne156() { if (length == 1) return true; return false; }
  boolean isLengthOne157() { if (length == 1) return true; return false; }
  boolean isLengthOne158() { if (length == 1) return true; return false; }
  boolean isLengthOne159() { if (length == 1) return true; return false; }
  boolean isLengthOne160() { if (length == 1) return true; return false; }
  boolean isLengthOne161() { if (length == 1) return true; return false; }
  boolean isLengthOne162() { if (length == 1) return true; return false; }
  boolean isLengthOne163() { if (length == 1) return true; return false; }
  boolean isLengthOne164() { if (length == 1) return true; return false; }
  boolean isLengthOne165() { if (length == 1) return true; return false; }
  boolean isLengthOne166() { if (length == 1) return true; return false; }
  boolean isLengthOne167() { if (length == 1) return true; return false; }
  boolean isLengthOne168() { if (length == 1) return true; return false; }
  boolean isLengthOne169() { if (length == 1) return true; return false; }
  boolean isLengthOne170() { if (length == 1) return true; return false; }
  boolean isLengthOne171() { if (length == 1) return true; return false; }
  boolean isLengthOne172() { if (length == 1) return true; return false; }
  boolean isLengthOne173() { if (length == 1) return true; return false; }
  boolean isLengthOne174() { if (length == 1) return true; return false; }
  boolean isLengthOne175() { if (length == 1) return true; return false; }
  boolean isLengthOne176() { if (length == 1) return true; return false; }
  boolean isLengthOne177() { if (length == 1) return true; return false; }
  boolean isLengthOne178() { if (length == 1) return true; return false; }
  boolean isLengthOne179() { if (length == 1) return true; return false; }
  boolean isLengthOne180() { if (length == 1) return true; return false; }
  boolean isLengthOne181() { if (length == 1) return true; return false; }
  boolean isLengthOne182() { if (length == 1) return true; return false; }
  boolean isLengthOne183() { if (length == 1) return true; return false; }
  boolean isLengthOne184() { if (length == 1) return true; return false; }
  boolean isLengthOne185() { if (length == 1) return true; return false; }
  boolean isLengthOne186() { if (length == 1) return true; return false; }
  boolean isLengthOne187() { if (length == 1) return true; return false; }
  boolean isLengthOne188() { if (length == 1) return true; return false; }
  boolean isLengthOne189() { if (length == 1) return true; return false; }
  boolean isLengthOne190() { if (length == 1) return true; return false; }
  boolean isLengthOne191() { if (length == 1) return true; return false; }
  boolean isLengthOne192() { if (length == 1) return true; return false; }
  boolean isLengthOne193() { if (length == 1) return true; return false; }
  boolean isLengthOne194() { if (length == 1) return true; return false; }
  boolean isLengthOne195() { if (length == 1) return true; return false; }
  boolean isLengthOne196() { if (length == 1) return true; return false; }
  boolean isLengthOne197() { if (length == 1) return true; return false; }
  boolean isLengthOne198() { if (length == 1) return true; return false; }
  boolean isLengthOne199() { if (length == 1) return true; return false; }
  boolean isLengthOne200() { if (length == 1) return true; return false; }
  boolean isLengthOne201() { if (length == 1) return true; return false; }
  boolean isLengthOne202() { if (length == 1) return true; return false; }
  boolean isLengthOne203() { if (length == 1) return true; return false; }
  boolean isLengthOne204() { if (length == 1) return true; return false; }
  boolean isLengthOne205() { if (length == 1) return true; return false; }
  boolean isLengthOne206() { if (length == 1) return true; return false; }
  boolean isLengthOne207() { if (length == 1) return true; return false; }
  boolean isLengthOne209() { if (length == 1) return true; return false; }
  boolean isLengthOne210() { if (length == 1) return true; return false; }
  boolean isLengthOne211() { if (length == 1) return true; return false; }
  boolean isLengthOne212() { if (length == 1) return true; return false; }
  boolean isLengthOne213() { if (length == 1) return true; return false; }
  boolean isLengthOne214() { if (length == 1) return true; return false; }
  boolean isLengthOne215() { if (length == 1) return true; return false; }
  boolean isLengthOne216() { if (length == 1) return true; return false; }
  boolean isLengthOne217() { if (length == 1) return true; return false; }
  boolean isLengthOne218() { if (length == 1) return true; return false; }
  boolean isLengthOne219() { if (length == 1) return true; return false; }
  boolean isLengthOne220() { if (length == 1) return true; return false; }
  boolean isLengthOne221() { if (length == 1) return true; return false; }
  boolean isLengthOne222() { if (length == 1) return true; return false; }
  boolean isLengthOne223() { if (length == 1) return true; return false; }
  boolean isLengthOne224() { if (length == 1) return true; return false; }
  boolean isLengthOne225() { if (length == 1) return true; return false; }
  boolean isLengthOne226() { if (length == 1) return true; return false; }
  boolean isLengthOne227() { if (length == 1) return true; return false; }
  boolean isLengthOne228() { if (length == 1) return true; return false; }
  boolean isLengthOne229() { if (length == 1) return true; return false; }
  boolean isLengthOne230() { if (length == 1) return true; return false; }
  boolean isLengthOne231() { if (length == 1) return true; return false; }
  boolean isLengthOne232() { if (length == 1) return true; return false; }
  boolean isLengthOne233() { if (length == 1) return true; return false; }
  boolean isLengthOne234() { if (length == 1) return true; return false; }
  boolean isLengthOne235() { if (length == 1) return true; return false; }
  boolean isLengthOne236() { if (length == 1) return true; return false; }
  boolean isLengthOne237() { if (length == 1) return true; return false; }
  boolean isLengthOne238() { if (length == 1) return true; return false; }
  boolean isLengthOne239() { if (length == 1) return true; return false; }
  boolean isLengthOne240() { if (length == 1) return true; return false; }
  boolean isLengthOne241() { if (length == 1) return true; return false; }
  boolean isLengthOne242() { if (length == 1) return true; return false; }
  boolean isLengthOne243() { if (length == 1) return true; return false; }
  boolean isLengthOne244() { if (length == 1) return true; return false; }
  boolean isLengthOne245() { if (length == 1) return true; return false; }
  boolean isLengthOne246() { if (length == 1) return true; return false; }
  boolean isLengthOne247() { if (length == 1) return true; return false; }
  boolean isLengthOne248() { if (length == 1) return true; return false; }
  boolean isLengthOne249() { if (length == 1) return true; return false; }
  boolean isLengthOne250() { if (length == 1) return true; return false; }
  boolean isLengthOne251() { if (length == 1) return true; return false; }
  boolean isLengthOne252() { if (length == 1) return true; return false; }
  boolean isLengthOne253() { if (length == 1) return true; return false; }
  boolean isLengthOne254() { if (length == 1) return true; return false; }
  boolean isLengthOne255() { if (length == 1) return true; return false; }
  boolean isLengthOne256() { if (length == 1) return true; return false; }
  boolean isLengthOne257() { if (length == 1) return true; return false; }
  boolean isLengthOne258() { if (length == 1) return true; return false; }
  boolean isLengthOne259() { if (length == 1) return true; return false; }
  boolean isLengthOne260() { if (length == 1) return true; return false; }
  boolean isLengthOne261() { if (length == 1) return true; return false; }
  boolean isLengthOne262() { if (length == 1) return true; return false; }
  boolean isLengthOne263() { if (length == 1) return true; return false; }
  boolean isLengthOne264() { if (length == 1) return true; return false; }
  boolean isLengthOne265() { if (length == 1) return true; return false; }
  boolean isLengthOne266() { if (length == 1) return true; return false; }
  boolean isLengthOne267() { if (length == 1) return true; return false; }



  public static int main() {

    // step 1: plant a banana farm
     invoking_banana farm[] = { null, null, null};    

     
     
     // step 2: mexican banana's start to grow
     for (int i = 0; i < 3; i++){ 

        // invokespecial -> invokenonvirtual_quick
        farm[i] = new invoking_banana('m', 0, 0.0, "green");

        // verify construction
        if (farm[i].color != "green") return 2;
        if (farm[i].ctry_code != 'm') return 2;
        if (farm[i].length != 0) return 2;
        if (farm[i].diameter != 0.0) return 2;
        if (farm[i].calories != 0) return 2; // calories not initialized in
	                                     // constructor, should be 
	                                     // initialized by "new"
  
        if (farm[i].daysTilIRot != 5) return 2; // superclass constructor
        if (farm[i].nutritionValue != 1.2345) return 2;
        if (farm[i].citrus) return 2;

        if (!farm[i].name.equals("")) return 2;

        if ( !((fruit)farm[i]).color.equals("none")) return 2;
        if (farm[i].fat_grams != 0) return 2;

     }
      



     // step 3: some banana's just rot and die
     farm[0].daysTilIRot = 0;
     farm[1].daysTilIRot = 0;


     // step4: surviving bananas grow
     for(int days = 1; days <= 3; days++){
        
        farm[2].growLonger();   // invokespecial -> invokenonvirtual_quick
        
        farm[2].decrementLife(); // invokespecial -> invokesuper_quick
        
        farm[2].isLengthOne1();  // invokevirtual -> invokevirtual_quick
	
        farm[2].isLengthOne267(); // invokevirtual -> invokevirtual_quick_w
        
        if (!(farm.equals(farm))) return 2; // invokevirtual -> 
	                                    // invokevirtualobject_quick
     }

    if (farm[2].length != 3) return 2;
    if (farm[2].daysTilIRot != 2) return 2; 
   
    // System.out.println("pass");
    return 0;
      
  }

  
}
