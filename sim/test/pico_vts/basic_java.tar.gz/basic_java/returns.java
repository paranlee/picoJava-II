//****************************************************************
//***
//***    Copyright 1999 Sun Microsystems, Inc., 901 San Antonio
//***    Road, Palo Alto, CA 94303, U.S.A.  All Rights Reserved.
//***    The contents of this file are subject to the current
//***    version of the Sun Community Source License, picoJava-II
//***    Core ("the License").  You may not use this file except
//***    in compliance with the License.  You may obtain a copy
//***    of the License by searching for "Sun Community Source
//***    License" on the World Wide Web at http://www.sun.com.
//***    See the License for the rights, obligations, and
//***    limitations governing use of the contents of this file.
//***
//***    Sun, Sun Microsystems, the Sun logo, and all Sun-based
//***    trademarks and logos, Java, picoJava, and all Java-based
//***    trademarks and logos are trademarks or registered trademarks
//***    of Sun Microsystems, Inc. in the United States and other
//***    countries.
//***
//*****************************************************************



class returns {

  public static int ireturn (int i, long l, double d, short s, byte b, float f,  char c, String a[])
  {
    return i;
  }

  public static long lreturn (int i, long l, double d, short s, byte b, float f,  char c, String a[])
  {
    return l;
  }

   public static double dreturn (int i, long l, double d, short s, byte b, float f,  char c, String a[])
  {
    return d;
  }

  public static short sreturn (int i, long l, double d, short s, byte b, float f,  char c, String a[])
  {
    return s;
  }

   public static byte breturn (int i, long l, double d, short s, byte b, float f,  char c, String a[])
  {
    return b;
  }

    public static float freturn (int i, long l, double d, short s, byte b, float f,  char c, String a[])
  {
    return f;
  }

  public static char creturn (int i, long l, double d, short s, byte b, float f,  char c, String a[])
  {
    return c;
  }

  public static Object areturn (int i, long l, double d, short s, byte b, float f,  char c, String a[])
  {
    return a;
  }

 

  public static void vreturn (int i, long l, double d, short s, byte b, float f,  char c, String a[])
  {
    return;
  }

  public static int main() 
  {
	int MAX = 3; // this can be changed to any length desired -
		     // deliberately kept low for now so it doesn't
		     // take too long on RTL.


        int i = 0x75640123;
        float f = 3.14f;
        double d = 5.00125;
        char c = 0xf123;
        byte b = (byte)0xf4;
        short s = (short)0xfade;
        long l = 0xabcdef1234567890l;
        String[] chiles = { "jalapeno", "anaheim", "serrano", "habanero", "thai"};

        for (int j = 0; j < MAX; j++)
           ireturn(i, l, d, s, b, f, c, chiles);

        for (int j = 0; j < MAX; j++)
           freturn(i, l, d, s, b, f, c, chiles);

        for (int j = 0; j < MAX; j++)
           sreturn(i, l, d, s, b, f, c, chiles);

        for (int j = 0; j < MAX; j++)
           creturn(i, l, d, s, b, f, c, chiles);

        for (int j = 0; j < MAX; j++)
           breturn(i, l, d, s, b, f, c, chiles);

        for (int j = 0; j < MAX; j++)
           dreturn(i, l, d, s, b, f, c, chiles);

        for (int j = 0; j < MAX; j++)
           lreturn(i, l, d, s, b, f, c, chiles);

        for (int j = 0; j < MAX; j++)
           areturn(i, l, d, s, b, f, c, chiles);
   
        for (int j = 0; j < MAX; j++)
           vreturn(i, l, d, s, b, f, c, chiles);


        // System.out.println("pass");
        return 0;
  }

}


