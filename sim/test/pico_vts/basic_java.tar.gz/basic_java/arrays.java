//****************************************************************
//***
//***    Copyright 1999 Sun Microsystems, Inc., 901 San Antonio
//***    Road, Palo Alto, CA 94303, U.S.A.  All Rights Reserved.
//***    The contents of this file are subject to the current
//***    version of the Sun Community Source License, picoJava-II
//***    Core ("the License").  You may not use this file except
//***    in compliance with the License.  You may obtain a copy
//***    of the License by searching for "Sun Community Source
//***    License" on the World Wide Web at http://www.sun.com.
//***    See the License for the rights, obligations, and
//***    limitations governing use of the contents of this file.
//***
//***    Sun, Sun Microsystems, the Sun logo, and all Sun-based
//***    trademarks and logos, Java, picoJava, and all Java-based
//***    trademarks and logos are trademarks or registered trademarks
//***    of Sun Microsystems, Inc. in the United States and other
//***    countries.
//***
//*****************************************************************



// Simple test to check load, store, length of arrays 

public class arrays {
   
   char ctry_code;
   int size;
   double ver;
   String clss_name;
  

   arrays (char cty, int l, double v, String clss){
     ctry_code = cty;
     size = l;
     ver = v;
     clss_name = clss;
   }

   public static int main() {
	int MAX = 2; // this can be changed to any length desired -
		     // deliberately kept low for now so it doesn't
		     // take too long on RTL.
	int i, j, k; // array indices
        int iarray[]= new int [MAX];
        float farray[]= new float [MAX];
        long larray[]= new long [MAX];
        double darray[]= new double [MAX];
        byte barray[]= new byte [MAX];
        short sarray[]= new short [MAX];
        char carray[]= new char [MAX];
        arrays a1[] = new arrays [MAX];
        arrays a2[][] = new arrays [MAX][MAX];
        arrays a3[][][] = new arrays [MAX][MAX][MAX];

		if (iarray.length != MAX)
			return 2;

		if (farray.length != MAX)
			return 2;
		if (larray.length != MAX)
			return 2;
		if (darray.length != MAX)
			return 2;
		if (barray.length != MAX)
			return 2;
		if (sarray.length != MAX)
			return 2;
		if (carray.length != MAX)
			return 2;
                if (a1.length != MAX)
                        return 2;
                if (a2.length != MAX)
                        return 2;
                if (a3.length != MAX)
                        return 2;

                for (i = 0; i < MAX; i++){
                  if (a2[i].length != MAX) return 2;
                  for (j = 0; j < MAX; j++)
                     if(a3[i][j].length != 2) return 2;
                }



		for (i = 0 ; i < MAX ; i++)
			iarray[i] = 0;
		for (i = 0 ; i < MAX ; i++)
			if (iarray[i] != 0)
				return (2);
		for (i = 0 ; i < MAX ; i++)
			iarray[i] = i;
		for (i = 0 ; i < MAX ; i++)
			if (iarray[i] != i)
				return (2);

		for (i = 0 ; i < MAX ; i++)
			farray[i] = 0;
		for (i = 0 ; i < MAX ; i++)
			if (farray[i] != 0)
				return (2);
		for (i = 0 ; i < MAX ; i++)
			farray[i] = i;
		for (i = 0 ; i < MAX ; i++)
			if (farray[i] != i)
				return (2);

		for (i = 0 ; i < MAX ; i++)
			larray[i] = 0;
		for (i = 0 ; i < MAX ; i++)
			if (larray[i] != 0)
				return (2);
		for (i = 0 ; i < MAX ; i++)
			larray[i] = i;
		for (i = 0 ; i < MAX ; i++)
			if (larray[i] != i)
				return (2);

		for (i = 0 ; i < MAX ; i++)
			darray[i] = 0;
		for (i = 0 ; i < MAX ; i++)
			if (darray[i] != 0)
				return (2);
		for (i = 0 ; i < MAX ; i++)
			darray[i] = i;
		for (i = 0 ; i < MAX ; i++)
			if (darray[i] != i)
				return (2);
        
		for (i = 0 ; i < MAX ; i++)
			sarray[i] = 0;
		for (i = 0 ; i < MAX ; i++)
			if (sarray[i] != 0)
				return (2);
		for (i = 0 ; i < MAX ; i++)
			sarray[i] = (short) i;
		for (i = 0 ; i < MAX ; i++)
			if (sarray[i] != (short) i)
				return (2);
        
		for (i = 0 ; i < MAX ; i++)
			barray[i] = 0;
		for (i = 0 ; i < MAX ; i++)
			if (barray[i] != 0)
				return (2);
		for (i = 0 ; i < MAX ; i++)
			barray[i] = (byte) i;
		for (i = 0 ; i < MAX ; i++)
			if (barray[i] != (byte) i)
				return (2);
        
		for (i = 0 ; i < MAX ; i++)
			carray[i] = 0;
		for (i = 0 ; i < MAX ; i++)
			if (carray[i] != 0)
				return (2);
		for (i = 0 ; i < MAX ; i++)
			carray[i] = (char) i;
		for (i = 0 ; i < MAX ; i++)
			if (carray[i] != (char) i)
				return (2);


                for (i = 0; i < MAX; i++) {
                   a1[i] = new arrays('u', MAX, 2.345, "arrays");
                   if( !a1[i].clss_name.equals("arrays") ) return 2;

                   for (j = 0; j < MAX; j++) {
                         a2[i][j] = new arrays('u', MAX, 2.345, "arrays");
                         if(!a2[i][j].clss_name.equals("arrays")) return 2;

		      for (k=0; k < MAX; k++) {
		        a3[i][j][k] = new arrays('u', MAX, 2.345, "arrays");
		        if( !a3[i][j][k].clss_name.equals("arrays") ) return 2;
		      }

                   }
                }

	       //System.out.println("pass");               
               return (0);
  }
}









