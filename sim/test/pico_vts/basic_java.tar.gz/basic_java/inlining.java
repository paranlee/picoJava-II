//****************************************************************
//***
//***    Copyright 1999 Sun Microsystems, Inc., 901 San Antonio
//***    Road, Palo Alto, CA 94303, U.S.A.  All Rights Reserved.
//***    The contents of this file are subject to the current
//***    version of the Sun Community Source License, picoJava-II
//***    Core ("the License").  You may not use this file except
//***    in compliance with the License.  You may obtain a copy
//***    of the License by searching for "Sun Community Source
//***    License" on the World Wide Web at http://www.sun.com.
//***    See the License for the rights, obligations, and
//***    limitations governing use of the contents of this file.
//***
//***    Sun, Sun Microsystems, the Sun logo, and all Sun-based
//***    trademarks and logos, Java, picoJava, and all Java-based
//***    trademarks and logos are trademarks or registered trademarks
//***    of Sun Microsystems, Inc. in the United States and other
//***    countries.
//***
//*****************************************************************



// not a very important test - we wrote this program anyway, 
// hence adding to the tests

public class inlining {
// test for simple inlining

public static int stat;
public int field;

// this'll check passthru invokestatic's
public static int foo_stat1 () { return (1 + 2); }
public static int foo_stat () { return foo_stat1 (); }

// private so it'll check passthru invokenonvirt's
private int foo_private1 () { return (1 + 2); }
private int foo_private () { return foo_private1 (); }

// this'll test passthru invokevirt's
public int foo_virt1 () { return (1 + 2); }
public int foo_virt () { return foo_virt1 (); }

// this'll test field getters and setters
public int getfield () { return this.field; }
public void putfield (int i) { this.field = i; }

// this'll test static getters and setters
public static int getstat () { return stat; }
public static void putstat (int i) { stat =  i; }

// empty returns is tested when we create an object

public static int main ()

{

for (int i = 0 ; i < 2 ; i++)
{
    inlining a = new inlining ();
    int x = a.foo_stat (); // pass thru stat fn.

    int y = a.foo_virt (); // pass thru virtual fn.

    a.putfield (a.getfield ()); // instance field setter and getter
    a.putstat (a.getstat ()); // static field setter and getter
}
    return 0;
}

}

